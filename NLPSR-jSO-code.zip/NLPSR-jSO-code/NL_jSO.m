clc;
clear all;

format long;
format compact;
tic;

fobj=str2func('cec17_func');
Fmin=100*(1:30);
problem_size=100;
max_nfes=10000*problem_size;
NPinit = ceil(75*problem_size^(2/3));
NPmin = 4;

'LSHADE-RSP'
fprintf("开始时间：%s", datestr(now));
rand('seed', sum(100 * clock));
for func = 1:30
    if func==2
        continue;
    end
    problem = func;
    optimum =100*func;
    outcome=[];
    %% printf the best results
    fprintf('\n')
    disp(['—————The LSHADE-RSP is optimizing, func is ',num2str(func),',  problem_size:',num2str(problem_size),'—————']);
    parfor run_id = 1:30
        pop_size = NPinit;
        lb=-100;
        ub=100;
        lb=lb.*ones(1,problem_size);
        ub=ub.*ones(1,problem_size);
        % Initialize parameter
        k=3;
        F = 0.3;
        CR = 0.8;
        H = 5;
        Arate= 1;
        flag=zeros(1,2);%1  P   ,  2   PA
        Flag=zeros(1,pop_size);% 1 P     ,    2  PA
        pr=0.5;
        nfes = 0;
        g = 1;
        A = [];% achieve
        nA = 0;% achieve size
        MF = F * ones(1, H);
        MCR = CR * ones(1, H);
        iM = 1;
        % Initialize population and Evaluation
        X = lb + (ub - lb) .* rand(pop_size,problem_size);
        fitness = feval(fobj,X',func);
        %         fitness = feval(fhd,pop',func);
        %fitness = benchmark_func(pop, problem);
        fitness = fitness';
        nfes = nfes + pop_size;
        [fitness, fidx] = sort(fitness);
        X = X(fidx,: );
        V = X;
        U = X;
        Chy = cauchyrnd(0, 0.1, 2*pop_size);
        iChy = 1;
        rcount=0;
        PR=ones(1,H)/H;

        %% main loop
        while nfes < max_nfes
            Rank_i1=1:pop_size;
            Rank1=k*(pop_size-Rank_i1)+1;
            Pr1=Rank1./sum(Rank1);
            Pr_1=fliplr(Pr1);

            PA=[X;A];

            p=0.085+0.085*nfes/max_nfes;

            MCR(H)=0.9;
            MF(H)=0.9;
            r=randsample(H,pop_size,true,PR);
            % Crossover rates
            CR = MCR(r) + 0.1 * randn(1, pop_size);
            CR((CR < 0) | (MCR(r) == -1)) = 0;
            CR(CR > 1) = 1;
            % Scaling factors
            F = zeros(1, pop_size);
            for i = 1 : pop_size
                while F(i) <= 0
                    F(i) = MF(r(i)) + Chy(iChy);
                    iChy = mod(iChy, numel(Chy)) + 1;
                end
            end
            F(F > 1) = 1;

            if nfes<0.6*max_nfes
                F(F>0.7) = 0.7;
            end
            if nfes<0.2*max_nfes
                FW = 0.7*F;
            elseif nfes<0.4*max_nfes
                FW = 0.8*F;
            else
                FW = 1.2*F;
            end
            if nfes<0.25*max_nfes
                CR(CR<0.7) = 0.7;
            elseif nfes<0.5*max_nfes
                CR(CR<0.6) = 0.6;
            end
            % pbest index
            pnum=max(2, round(p * pop_size));
            pbest = randi(pnum,1,pop_size);
            % Mutation
            %r1 = randi(pop_size,1,pop_size);
            %r1 = randsample(pop_size,pop_size,true,Pr1);
            if nfes<0.95*max_nfes
               r1 = randsample(pop_size,pop_size,true,Pr1);
            else
               r1 = randi(pop_size,1,pop_size);
            end
            r2 = randi(pop_size,1,pop_size);
            r3 = randi(pop_size+nA,1,pop_size);
            for i = 1 : pop_size
                while i == r1(i)
                    if rcount<10
                        r1(i) =randi(pop_size,1,1);
                        rcount=rcount+1;
                    else
                        break;
                    end
                end
                rcount=0;
                while i == r2(i) || r1(i) == r2(i)
                    if rcount<10
                        r2(i) =randi(pop_size,1,1);
                        rcount=rcount+1;
                    else
                        break;
                    end
                end
                rcount=0;
                while i == r3(i) || r1(i) == r3(i)
                    if rcount<10
                        r3(i) =randi(pop_size+nA,1,1);
                        rcount=rcount+1;
                    else
                        break;
                    end
                end
                rcount=0;

                if nA==0
                    pr=0.5;
                else
                    pr=flag(1)/(flag(1)+flag(2));
                end

                if rand<pr
                    V(i,:) = X(i,:) + FW(i) .* (X(pbest(i),:) - X(i,:)) + F(i) .* (X(r1(i),:) - X(r2(i),:));
                    flag(1)=flag(1)+1;
                    Flag(i)=1;
                else
                    V(i,:) = X(i,:) + FW(i) .* (X(pbest(i),:) - X(i,:)) + F(i) .* (X(r1(i),:) - PA(r3(i),:));
                    flag(2)=flag(2)+1;
                    Flag(i)=2;
                end

                for j = 1 : problem_size
                    if V(i, j) < lb(j)
                        V(i, j) = 0.5 * (lb(j) + X(i, j));
                    end
                    if V(i, j) > ub(j)
                        V(i, j) = 0.5 * (ub(j) + X(i, j));
                    end
                end
                jrand = randi(problem_size);
                for j = 1 : problem_size
                    if rand <= CR(i) || j == jrand
                        U(i, j) = V(i, j);
                    else
                        U(i, j) = X(i, j);
                    end
                end
            end
            children_fitness=feval(fobj,U',func);
            children_fitness = children_fitness';
            for i=1:pop_size
                if children_fitness(i)>=fitness(i) && Flag(i)==1
                    flag(1)=flag(1)-1;
                end
                if children_fitness(i)>=fitness(i) && Flag(i)==2
                    flag(2)=flag(2)-1;
                end
            end
            nfes = nfes + pop_size;
            bR=children_fitness<fitness;
            % Selection
            nS=sum(bR);
            A= [A;X(bR,:)]; %A是外部存档
            nA= nA + nS; %A中的元素个数
            S_CR	= CR(bR);
            S_F		= F(bR);
            S_df	= abs(children_fitness(bR) - fitness(bR));
            X(bR,:)		= U(bR,:);
            fitness(bR)	= children_fitness(bR);
            % Update MCR and MF
            if nS > 0
                w = S_df(1 : nS) ./ sum(S_df(1 : nS));
                if all(S_CR(1 : nS) == 0)
                    MCR(iM) = -1;
                elseif MCR(iM) ~= -1
                    MCR(iM) = (sum(w .* S_CR(1 : nS) .* S_CR(1 : nS)) / sum(w .* S_CR(1 : nS))+MCR(iM))/2;
                end
                MF(iM) = (sum(w .* S_F(1 : nS) .* S_F(1 : nS)) / sum(w .* S_F(1 : nS))+MF(iM))/2;
                iM = mod(iM, H-1) + 1;
            end
            % Sort
            [fitness, fidx] = sort(fitness);
            X = X(fidx,:);
            % Update NP and population
            m = nfes / max_nfes;
            k1=1.6;
            k2=2.0;
            pop_size = round(NPinit + (NPmin - NPinit) * m .^ (k1*exp(k2*(-m))));
            fitness = fitness(1 : pop_size);
            X = X(1 : pop_size,:);
            U = U(1 : pop_size,:);
            Asize = round(Arate*pop_size);
            if nA>Asize
                A=A((nA-Asize+1):nA,:);
                nA=Asize;
            end
            bsf_error_val = fitness(1)-optimum;
            if bsf_error_val < 10^-8
                bsf_error_val = 0;
            end
            %NL_jSO_Cov(func,g)=bsf_error_val;
            g = g + 1;
        end
        NL_jSO_result(func,run_id) = bsf_error_val;
        outcome = [outcome bsf_error_val];
        bestX_pos = X(1,:);
        fprintf('func is %d, %d th run, best value = %1.8e\n', func , run_id , bsf_error_val)
    end
    fprintf('\n')
    display(['The mean fitness F',num2str(func),' is : ',num2str(mean(outcome))])
end
%path='C:\Users\91046\Desktop\NL-jSO\k1 1.6    k2 2.0\';
result_name = strcat('NL_jSO_result','_d',num2str(problem_size));
cov_name = strcat('NL_jSO_Cov','_d',num2str(problem_size));

save([path,result_name],'NL_jSO_result')
%save([path,cov_name],'NL_jSO_Cov')
toc;
fprintf("结束时间：%s", datestr(now))

